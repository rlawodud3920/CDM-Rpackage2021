SELECT row_id,
	covariate_id,
	covariate_value
FROM #cov_1

;